import wrapper

# cut and paste stows here
tanksVolValue = [100, 200, 300, 400, 500, 600, 700]
prodsVolValue = [800, 500, 700]

# How deep the bin packing algorithm is to search - larger the number the slower the outcome
depth = 10

# Requested outcomes.
requested_outcomes = 10

# The alternative is by_volume - in which case change argument to 'False'
sort_by_tankage = True

try:
    wrapper.wrap(tanksVolValue, prodsVolValue, depth, sort_by_tankage, requested_outcomes)
except:
    Exception

