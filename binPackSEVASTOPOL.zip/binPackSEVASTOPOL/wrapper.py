from bin import binPack
import time
import functools


import operator
from collections import Counter
from math import factorial
def npermutations(l):
    num = factorial(len(l))
    mults = Counter(l).values()
    den = functools.reduce(operator.mul, (factorial(v) for v in mults), 1)
    return num / den


def wrap(tanksVol, prodsVol, depth, tank, iterations):

    tanksVolValue = tanksVol
    prodsVolValue = prodsVol

    start = time.time()

    tVNalt = [x + 7001 for x, y in enumerate(tanksVolValue)]
    tanks = [x for x in zip(tVNalt, tanksVolValue)]
    print(tanks)
    print()


    # Instatiate object with default params
    binpack = binPack()

    # Change the default params. Any can be changed in this way.

    depth = depth * 100

    binpack.iterations = depth
    binpack.tankTrueOrVolumeFalse = tank

    # Calculate a pack with tVV, pVV
    result = binpack.getPack(tanksVolValue, prodsVolValue)
    stow = []

    if result:
        import operator

        alphanumbericAssigned = result['alphanumeric assigned'][0]
        alphanumbericAssigned = sorted(alphanumbericAssigned.items(), key=operator.itemgetter(1))
        remainingTanksLeft = result['remaining tanks (leftover)']
        remainingTanksTotal = result['remaining tanks (total)']
        remainingVolumeLeft = result['remaining volume (tanks)']
        remainingVolumeTotal = result['remaining volume (total)']
        stow = result['stow']
    else:
        print('No stow found. Try increasing the iteration factor.')

    end = time.time()
    end = end-start
    total = round(end,1)

    t = npermutations(tanksVolValue)
    p = npermutations(prodsVolValue)
    t = round((t*p),0)

    print('Unique combinations', len(stow))
    print('Time', total)
    print('Permutations', round(t))

    iterations = iterations

    if result:
        for x in range (0, iterations):

            try:
                print()
                print('STOW ', x+1)
                print(tanks)
                print('-'*5)
                print('Alphanumeric Assigned','\t\t\t',alphanumbericAssigned)
                print('Remaining tanks - ID','\t\t\t',remainingTanksLeft[x])
                print('Remaining tanks - total','\t\t', remainingTanksTotal[x])
                print('Remaining volume - Volume','\t\t', remainingVolumeLeft[x])
                print('Remaining volume - Individual','\t',remainingVolumeTotal[x])
                print()
                print('Resultant combination','\t\t\t',stow[x][0])
                print('Resultant combination', '\t\t\t', stow[x][1])
                print('-' * 5)
            except:
                break

